<section class="panel">

    <div class="panel-body">
        <ul class="nav nav-stacked">
            <li><a href="<?php echo site_url('site/editoffer?id=').$before->id; ?>">offer Details</a></li>
            <li><a href="<?php echo site_url('site/viewofferproduct?id=').$before->id; ?>">offer products</a></li>
        </ul>
    </div>
</section>